This is an example OpenRISC firmware for the Allwinner H3 SoC.
This firmware just blinking by onboard leds every second.


Requirements:

    Orange Pi One / Orange Pi PC
    Armbian mainline image

    
Howto:

    Copy these files to the /boot folder
    Restart the board


The source of this firmware:

    https://github.com/MX-Master/h3-firmware/tree/test_3
